// The browser's game storage: the Origin Private File System.
//
// # Why the container cannot just be bytes in memory
// A retail Vita title is over a gigabyte. Held as JS `ArrayBuffer`s it costs that much
// in the renderer, and copied into the emulator's wasm heap it costs it again - against
// a wasm32 address space that tops out at 4 GB. Measured on a 1719 MB title before this
// existed: Chrome peaked at 8.01 GB during ingest and the worker was killed mid-boot,
// which from outside looks like a page that has stopped answering rather than an
// out-of-memory error.
//
// So the container is never fully resident. It is STREAMED into OPFS - from the user's
// picked `.pkg` + `work.bin`, or from this origin for a test run - and read back in
// pieces. Peak memory during import is one chunk, not one title.
//
// # Why OPFS specifically, and not Cache Storage or IndexedDB
// Only OPFS offers `createSyncAccessHandle`, whose `read` is SYNCHRONOUS. That is not a
// convenience here, it is the requirement: the emulator serves guest file reads inside
// host calls, which are synchronous Rust running on a suspended guest stack. An async
// storage API could not back them without turning every guest read into a suspension.
// Sync access handles are available in Workers only - which is where the emulator runs.

/// Directory under the OPFS root holding one title's files, keyed by `id`.
export async function titleDir(id, { create = true } = {}) {
  const root = await navigator.storage.getDirectory();
  const games = await root.getDirectoryHandle("games", { create });
  return games.getDirectoryHandle(id, { create });
}

/// A file name safe to use as a flat OPFS entry, since OPFS has no path separators of
/// its own and a container's paths do. Reversed by `decodeName`.
export function encodeName(path) {
  return path.replace(/\//g, "%2F");
}

export function decodeName(name) {
  return name.replace(/%2F/g, "/");
}

/// Marker written LAST, after every file is durably stored. Its presence is what makes
/// an import complete: a run interrupted halfway leaves files behind but no marker, and
/// the next boot re-imports rather than mounting a truncated title. Storing the file
/// count too means a partial directory that somehow kept its marker is still caught.
const MANIFEST = "vitaslop-opfs-manifest.json";

/// Marker format version. An import made by an older build is REJECTED and redone.
///
/// >>> WHY A VERSION AND NOT JUST A NEW FIELD. Version 1 verified nothing about the bytes
/// > > > it stored: a source that answered a file request with an ERROR PAGE was imported as
/// > > > that file, and the marker then said the title was complete. One measured title's
/// > > > 2.9 GB archive came back as the nine bytes `not found` - the harness could not read a
/// > > > file over 2 GiB and returned its 404 body - and every later boot REUSED that import,
/// > > > because the only check was the file COUNT. The guest read nine ASCII bytes where its
/// > > > archive header belonged, took the failure branch of its loader, and ran on for three
/// > > > hundred frames with nothing loaded before dereferencing a registry that was never
/// > > > filled. Nothing in the run said "a file is wrong".
/// > > >
/// > > > A stored import that predates the size check cannot be distinguished from a correct
/// > > > one by inspecting it, so the version is what forces it to be redone once.
const MANIFEST_VERSION = 2;

/// Files an import keeps in flight at once - see `importTitle`.
const IMPORT_PARALLEL = 6;

/// Whether `id` has a complete import, whatever its size. The marker is written last.
export async function isComplete(id) {
  try {
    const dir = await titleDir(id, { create: false });
    const fh = await dir.getFileHandle(MANIFEST);
    const m = JSON.parse(await (await fh.getFile()).text());
    return m.complete === true;
  } catch {
    return false;
  }
}

/// Remove every stored byte of `id`, its add-ons and rePatch overlay included - both are part
/// of its title. The saves are elsewhere and untouched.
export async function removeTitle(id) {
  const root = await navigator.storage.getDirectory();
  for (const top of ["games", ADDONS, REPATCH]) {
    try {
      const d = await root.getDirectoryHandle(top, { create: false });
      await d.removeEntry(id, { recursive: true });
    } catch {}
  }
}

// ------------------------------- add-ons -------------------------------
//
// An add-on ("additional content") is stored like a title - the same flat, `%2F`-encoded dump
// - under `addons/<title id>/<dir>/`, where `<dir>` is the label that ends its content id and
// the name the title asks the system for. Its record `addon.json` and the completion marker sit
// beside its files. It belongs to its title: listed, added and removed on that title's page,
// and removed with it.

const ADDONS = "addons";
/// An add-on's record, beside its files. Not a dump path, so it is never served to the guest.
export const ADDON_RECORD = "addon.json";

/// The directory holding `id`'s add-ons.
export async function addonsDir(id, { create = true } = {}) {
  const root = await navigator.storage.getDirectory();
  const top = await root.getDirectoryHandle(ADDONS, { create });
  return top.getDirectoryHandle(id, { create });
}

/// Whether `dir` is a plain add-on directory name - it is joined onto storage paths.
export function isAddonName(dir) {
  return typeof dir === "string" && /^[A-Za-z0-9]{1,32}$/.test(dir);
}

/// The add-ons installed for `id` whose import completed, by title.
export async function listAddons(id) {
  let top;
  try {
    top = await addonsDir(id, { create: false });
  } catch {
    return [];
  }
  const out = [];
  for await (const [name, h] of top.entries()) {
    if (h.kind !== "directory") continue;
    try {
      const m = JSON.parse(await (await (await h.getFileHandle(MANIFEST)).getFile()).text());
      const rec = JSON.parse(await (await (await h.getFileHandle(ADDON_RECORD)).getFile()).text());
      if (m.complete === true && rec && rec.dir === name && rec.titleId === id) out.push(rec);
    } catch {
      // No marker or no record: an import that did not finish. Not an add-on.
    }
  }
  out.sort((a, b) => (a.title || a.dir).localeCompare(b.title || b.dir) || a.dir.localeCompare(b.dir));
  return out;
}

/// Remove one add-on of `id`.
export async function removeAddon(id, dir) {
  if (!isAddonName(dir)) throw new Error(`not an add-on name: ${dir}`);
  const top = await addonsDir(id, { create: false });
  await top.removeEntry(dir, { recursive: true });
}

/// Turn one add-on of `id` on or off. Off keeps every file; the game just does not see it.
export async function setAddonEnabled(id, dir, on) {
  if (!isAddonName(dir)) throw new Error(`not an add-on name: ${dir}`);
  const h = await (await addonsDir(id, { create: false })).getDirectoryHandle(dir);
  const rec = JSON.parse(await (await (await h.getFileHandle(ADDON_RECORD)).getFile()).text());
  rec.disabled = !on;
  await writeJson(h, ADDON_RECORD, rec);
}

async function writeJson(dir, name, value) {
  const w = await (await dir.getFileHandle(name, { create: true })).createWritable();
  await w.write(JSON.stringify(value));
  await w.close();
}

// ------------------------------ rePatch overlay ------------------------------
//
// A player's own modified or decrypted files laid over a title, as the device's rePatch plugin
// lays `ux0:rePatch/<id>/` over the game (see `ingest::repatch`). One per title, stored under
// `repatch/<id>/<gen>/` in the same flat `%2F`-encoded form - `app/...` over the game,
// `addcont/<dir>/...` over its add-ons - with the record `repatch/<id>/repatch.json` naming `gen`.
// A replacement is copied into a NEW generation and the record rewritten last, so a failed one
// leaves the old overlay in place (OPFS cannot rename a directory). The game itself is never
// touched: the overlay is turned off, replaced or removed on its own.

const REPATCH = "repatch";
/// The overlay's record, written last: its presence is what makes an overlay complete.
export const REPATCH_RECORD = "repatch.json";

export async function repatchDir(id, { create = true } = {}) {
  const root = await navigator.storage.getDirectory();
  const top = await root.getDirectoryHandle(REPATCH, { create });
  return top.getDirectoryHandle(id, { create });
}

/// The overlay installed for `id`, or null.
export async function readRepatch(id) {
  try {
    const d = await repatchDir(id, { create: false });
    const rec = JSON.parse(await (await (await d.getFileHandle(REPATCH_RECORD)).getFile()).text());
    return rec && rec.titleId === id && typeof rec.gen === "string" ? rec : null;
  } catch {
    return null;
  }
}

/// Turn `id`'s overlay on or off. Off keeps every file.
export async function setRepatchEnabled(id, on) {
  const rec = await readRepatch(id);
  if (!rec) throw new Error(`${id} has no rePatch overlay`);
  rec.disabled = !on;
  await writeJson(await repatchDir(id, { create: false }), REPATCH_RECORD, rec);
}

export async function removeRepatch(id) {
  const root = await navigator.storage.getDirectory();
  try {
    await (await root.getDirectoryHandle(REPATCH, { create: false })).removeEntry(id, { recursive: true });
  } catch {}
}

/// The compile-cache name part an ENABLED overlay with code adds - see `transpile-worker.js`.
/// Empty when there is none, so a title without one keeps the name it always had.
export async function repatchCodeSuffix(id) {
  const rec = await readRepatch(id);
  return rec && !rec.disabled && rec.codeHash ? `-rp${rec.codeHash}` : "";
}

/// Whether `id` is already imported and complete. Cheap: one read of the marker.
///
/// An import whose marker predates [`MANIFEST_VERSION`] is treated as ABSENT, so it is redone
/// under the size checks - see the note on that constant for what a stored import could be.
export async function isImported(id, expectedCount) {
  try {
    const dir = await titleDir(id, { create: false });
    const fh = await dir.getFileHandle(MANIFEST);
    const m = JSON.parse(await (await fh.getFile()).text());
    return m.count === expectedCount && m.complete === true && m.v === MANIFEST_VERSION;
  } catch {
    return false;
  }
}

/// Stream one `ReadableStream` (or `Blob`) into `dir` under `path`, without ever
/// holding the whole thing. Returns the bytes written.
///
/// `onBytes(n)` is called with each chunk's length as it passes through. It exists because
/// a container's bytes are NOT spread evenly over its files: one title puts 660 of its 688
/// MB into 28 of its 248 files, so a caller that only learns about a finished file shows a
/// frozen counter for the entire minutes-long download of a single large one - which reads
/// exactly like a hang, and was reported as one.
async function storeOne(dir, path, source, onBytes = () => {}) {
  const fh = await dir.getFileHandle(encodeName(path), { create: true });
  const w = await fh.createWritable();
  const stream = source instanceof Blob ? source.stream() : source;
  const counted = stream.pipeThrough(
    new TransformStream({
      transform(chunk, ctrl) {
        onBytes(chunk.byteLength);
        ctrl.enqueue(chunk);
      },
    })
  );
  // `pipeTo` hands the writable ownership of the stream and closes it on completion,
  // so a failure part-way cannot leave a half-written file locked open.
  await counted.pipeTo(w);
  return (await fh.getFile()).size;
}

/// The stored size of `path` in `dir`, or -1 when it is not stored.
async function storedSize(dir, path) {
  try {
    return (await (await dir.getFileHandle(encodeName(path))).getFile()).size;
  } catch {
    return -1;
  }
}

/// How much room this origin has, or `null` where the browser will not say.
///
/// # Why this is checked BEFORE an import and not caught after
/// A phone's quota for an origin is a fraction of its free disk, and these containers are
/// 237 MB to 1719 MB. Discovering the limit by hitting it means a `QuotaExceededError`
/// hundreds of megabytes into a download, over wifi, with the partial files still on disk.
/// Asking first costs one call and turns that into a sentence naming both numbers.
export async function storageRoom() {
  if (!navigator.storage || !navigator.storage.estimate) return null;
  const { quota, usage } = await navigator.storage.estimate();
  if (typeof quota !== "number") return null;
  return { quota, usage: usage || 0, free: quota - (usage || 0) };
}

/// Ask the browser to treat this origin's storage as persistent, so an imported title is not
/// evicted under disk pressure - re-importing a gigabyte is not a cost to pay silently.
/// Returns whether it was granted. A refusal is not fatal and is reported, not swallowed.
export async function requestPersistence() {
  if (!navigator.storage || !navigator.storage.persist) return false;
  try {
    return (await navigator.storage.persisted()) || (await navigator.storage.persist());
  } catch {
    return false;
  }
}

/// Import a whole container into OPFS from a list of `{ path, source }`, where `source()`
/// yields a `Blob`/`File` (the web form), a `ReadableStream` (a fetch body), or
/// `{ body, bytes }` - a stream together with the length its source PROMISED, which the
/// import then holds it to. Calls
/// `onProgress(done, total, bytes)` as it goes. Idempotent: an already-complete title
/// is left alone.
export async function importTitle(id, entries, onProgress = () => {}) {
  if (await isImported(id, entries.length)) {
    onProgress(entries.length, entries.length, 0, true);
    return { reused: true };
  }
  const dir = await titleDir(id);
  let bytes = 0;
  // Files finished, and the bytes of files still being written - progress counts both.
  let done = 0;
  let pending = 0;
  // >>> SEVERAL FILES IN FLIGHT. One at a time, every file pays a whole fetch round trip plus
  // an OPFS open and close before the next starts; a title of ~7,000 small files spent most of
  // its import in those gaps rather than moving bytes. Each file is still stored and checked
  // exactly as before - only their order of completion changes, and the marker below is still
  // written after every one of them has finished.
  let next = 0;
  const importOne = async (i) => {
    // RESUME: an entry that names its `size` and is already stored at exactly that size (an
    // earlier import cut off part-way, e.g. by a runner job's time limit) is kept, not refetched.
    if (typeof entries[i].size === "number") {
      const have = await storedSize(dir, entries[i].path);
      if (have === entries[i].size) {
        bytes += have;
        onProgress(++done, entries.length, bytes, false);
        return;
      }
    }
    // Report DURING each file as well as after it, throttled to every 4 MB so a slow large
    // file still moves the counter without flooding the caller. See `storeOne`.
    let inFlight = 0;
    let reported = 0;
    // A source may name the length it PROMISED (a fetch's `content-length`). See below.
    // Only a NUMBER is a promise: a `Blob` (so every `File`) has a `bytes()` METHOD, and reading
    // that as a length failed every file of an import in current Chrome.
    const src = await entries[i].source();
    const promised = src && typeof src === "object" && typeof src.bytes === "number" ? src.bytes : null;
    const body = src && typeof src === "object" && "body" in src ? src.body : src;
    const written = await storeOne(dir, entries[i].path, body, (n) => {
      inFlight += n;
      pending += n;
      if (inFlight - reported >= 4 << 20) {
        reported = inFlight;
        onProgress(done, entries.length, bytes + pending, false);
      }
    });
    pending -= inFlight;
    // >>> A FILE THAT DID NOT ARRIVE WHOLE IS NOT A FILE, AND MUST NOT BE STORED AS ONE.
    //
    // A source that promises a length and delivers another has failed, whatever the transport
    // said: a truncated download, a proxy that cut the body, a server that answered the
    // request with an error page. Importing it anyway produces a title that BOOTS and is
    // wrong - the guest reads its own asset, gets something else, and takes a branch nobody
    // can trace back here. That is the failure this whole check exists to prevent; see
    // `MANIFEST_VERSION` for the run that made it necessary.
    if (promised !== null && written !== promised) {
      throw new Error(
        `import of ${entries[i].path} stored ${written} bytes but the source promised ` +
          `${promised} - the file did not arrive whole, and a partial asset is not importable`
      );
    }
    bytes += written;
    onProgress(++done, entries.length, bytes, false);
  };
  // A failed file rejects its worker, and `Promise.all` rejects the import with it - the marker
  // below is never written for a title with a file missing.
  await Promise.all(
    Array.from({ length: Math.min(IMPORT_PARALLEL, entries.length) }, async () => {
      while (next < entries.length) await importOne(next++);
    })
  );
  // The marker goes last, so "present" always means "everything before it is there".
  const fh = await dir.getFileHandle(MANIFEST, { create: true });
  const w = await fh.createWritable();
  await w.write(
    JSON.stringify({ complete: true, count: entries.length, bytes, v: MANIFEST_VERSION })
  );
  await w.close();
  return { reused: false, bytes };
}

/// Open every stored file of `id` as a SYNCHRONOUS access handle, returned as
/// `{ path: handle }`. Worker-only. This is the async step that buys synchronous reads
/// later - the emulator cannot await inside a guest file read, so every handle it may
/// need has to be open before the guest starts.
///
/// `skip(path)`, when given, names paths that are LISTED but not opened (`handles.skipped`):
/// the transpile worker reads only the manifest and the modules, and opening and then
/// closing a title's data files cost it ~16 s on the phone for 7122 of them (`syncReader`
/// reports a read of a skipped path as a failure rather than as a missing file).
export async function openTitleSync(id, { skip } = {}) {
  // >>> A RELOAD RACES THE PREVIOUS WORKER'S TEARDOWN, AND THAT IS THE NORMAL PATH.
  //
  // A sync access handle is EXCLUSIVE per file. The run worker holds one per file for the
  // whole session, and when the page is reloaded the browser tears that worker down
  // ASYNCHRONOUSLY - while the new page's transpile worker is already starting. The handles
  // are still held for a moment, and the open fails with
  // `NoModificationAllowedError: Access Handles cannot be created if there is another open
  // Access Handle or Writable stream associated with the same file`.
  //
  // Reported by the user on a plain reload of a single tab, with no second tab anywhere:
  // BOOT FAILED, no adapter, no audio, nothing playable. So this is not a multi-tab edge
  // case, it is what reloading a running title does.
  //
  // >>> AND THE FAILURE USED TO POISON EVERY RETRY. If the throw came part-way through the
  // loop, the handles already opened were dropped on the floor still OPEN - held by this
  // worker, for as long as it lives. A second attempt then collided with itself, so the
  // condition could never clear. Closing the partial set is what makes retrying meaningful.
  const DELAYS_MS = [0, 100, 200, 400, 800, 1500];
  let last;
  for (const wait of DELAYS_MS) {
    if (wait) await new Promise((r) => setTimeout(r, wait));
    const t0 = performance.now();
    const handles = {};
    const skipped = [];
    try {
      const todo = await listTitleFiles(id);
      if (skip) {
        const keep = [];
        for (const t of todo) (skip(t[0]) ? skipped : keep).push(t);
        todo.length = 0;
        todo.push(...keep);
        for (let i = 0; i < skipped.length; i++) skipped[i] = skipped[i][0];
      }
      const tListed = performance.now();
      // >>> OPENED SEVERAL AT A TIME. Each `createSyncAccessHandle` is a round trip to the
      // browser's storage process, and one at a time a title of 7122 files spent ~54 s of the
      // phone's boot at f0 here - twice, once in the transpile worker and once in the storage
      // worker. The cost is the trip, not the file, so the trips are overlapped. A failure
      // still closes every handle opened so far (the `catch` below), after the rest settle.
      const IN_FLIGHT = 32;
      let next = 0;
      let failed = null;
      const lane = async () => {
        while (next < todo.length && !failed) {
          const [path, h] = todo[next++];
          try {
            handles[path] = await h.createSyncAccessHandle();
          } catch (e) {
            failed = failed || e;
          }
        }
      };
      await Promise.all(Array.from({ length: Math.min(IN_FLIGHT, todo.length) }, lane));
      if (failed) throw failed;
      // What the open cost, for the prepare split, and what was left shut - non-enumerable,
      // so neither is a path.
      Object.defineProperty(handles, "openStats", {
        value:
          `${todo.length} files: listed ${Math.round(tListed - t0)} ms, opened ${Math.round(performance.now() - tListed)} ms` +
          (skipped.length ? ` (${skipped.length} data files listed, not opened)` : ""),
      });
      Object.defineProperty(handles, "skipped", { value: skipped });
      return handles;
    } catch (e) {
      for (const h of Object.values(handles)) {
        try {
          h.close();
        } catch {
          // Already closed, or the handle died with its file. Nothing to do, and it must not
          // mask the original failure below.
        }
      }
      last = e;
      if (e && e.name !== "NoModificationAllowedError") throw e;
    }
  }
  throw new Error(
    `this title's files are still open in another worker, so they cannot be opened again ` +
      `(${last}). That is usually the previous run still shutting down - reloading again ` +
      `after a moment normally clears it. If it does not, close every tab on this address ` +
      `(the handles are released when the last one goes) and open it again.`,
  );
}

/// Every stored file of `id` as `[path, FileSystemFileHandle]`, NOT opened: the title's own
/// files, then its installed add-ons' under `addons/<dir>/` - the prefix the engine looks for
/// (`opfs.rs` ADDONS_PREFIX) - then its rePatch overlay's under `repatch/` (`REPATCH_PREFIX`).
/// Only complete, ENABLED add-ons and overlays: a half-imported one is not one, and a turned-off
/// one is not there as far as the game can tell.
export async function listTitleFiles(id) {
  const dir = await titleDir(id, { create: false });
  const out = [];
  for await (const [name, h] of dir.entries()) {
    if (name === MANIFEST || h.kind !== "file") continue;
    out.push([decodeName(name), h]);
  }
  for (const rec of await listAddons(id)) {
    if (rec.disabled) continue;
    const adir = await (await addonsDir(id, { create: false })).getDirectoryHandle(rec.dir);
    for await (const [name, h] of adir.entries()) {
      if (name === MANIFEST || name === ADDON_RECORD || h.kind !== "file") continue;
      out.push([`${ADDONS}/${rec.dir}/${decodeName(name)}`, h]);
    }
  }
  const rp = await readRepatch(id);
  if (rp && !rp.disabled) {
    const gen = await (await repatchDir(id, { create: false })).getDirectoryHandle(rp.gen);
    for await (const [name, h] of gen.entries()) {
      if (h.kind !== "file") continue;
      out.push([`${REPATCH}/${decodeName(name)}`, h]);
    }
  }
  return out;
}

/// ONE file's sync access handle, retried while a previous worker's handle on it is still
/// being torn down - the reload race [`openTitleSync`] describes, met one file at a time by a
/// reader that opens on first use (`storage-worker.js`).
export async function openSyncRetrying(fileHandle) {
  const DELAYS_MS = [0, 100, 200, 400, 800, 1500];
  let last;
  for (const wait of DELAYS_MS) {
    if (wait) await new Promise((r) => setTimeout(r, wait));
    try {
      return await fileHandle.createSyncAccessHandle();
    } catch (e) {
      last = e;
      if (!e || e.name !== "NoModificationAllowedError") throw e;
    }
  }
  throw last;
}

/// A reader the wasm side calls: `size(path)` and `read(path, offset, into)`, both
/// synchronous. `into` is a `Uint8Array` view the caller owns; the return is how many
/// bytes were actually read (short at end of file, 0 for an unknown path).
export function syncReader(handles) {
  const skipped = new Set(handles.skipped || []);
  // A skipped path the engine asked for: it would read as MISSING, which is a wrong answer,
  // not an absent file - the caller checks `touchedSkipped()` and fails the run with it.
  const touched = new Set();
  return {
    paths: () => Object.keys(handles).concat([...skipped]),
    size: (path) => {
      if (handles[path]) return handles[path].getSize();
      if (skipped.has(path)) touched.add(path);
      return -1;
    },
    touchedSkipped: () => [...touched],
    read: (path, offset, into) => {
      const h = handles[path];
      return h ? h.read(into, { at: offset }) : 0;
    },
    close: () => {
      for (const h of Object.values(handles)) h.close();
    },
  };
}

// >>> THE RUN'S READER: A PAGE RING FILLED BY A SEPARATE STORAGE WORKER.
//
// `syncReader` above makes every read a synchronous trip through the browser's storage
// stack on the emulator's own thread - about a millisecond per 64 KB where it was measured,
// several times a frame while a title streams. `openTitleCached` moves the handles to
// `storage-worker.js`, which serves 64 KB pages into this ring and reads AHEAD along the
// file between requests, so a sequential stream is answered out of shared memory and the
// emulator waits only on a genuine miss. See the header of storage-worker.js.
//
// Layout of the `SharedArrayBuffer`, as `Int32Array` indices: a small header, one tag per
// slot, then - at `DATA_OFF` bytes - `SLOTS` pages of `PAGE` bytes.
export const PAGE = 64 * 1024;
export const SLOTS = 128;
export const H = {
  REQ: 0, // 1 while a request is posted
  ACK: 1, // count of requests completed
  CLOSE: 2, // 1 asks the worker to close its handles and exit
  ERR: 3, // nonzero once the worker has failed a read; the reader then reports rather than waits
  REQ_PATH: 4,
  REQ_PAGE: 5,
  REQ_COUNT: 6,
  TAGS: 8,
};
export const TAG = { PATH: 0, PAGE: 1, STATE: 2, LEN: 3, STRIDE: 4 };
export const STATE = { READY: 0, FILLING: 1, PINNED: 2 };
export const DATA_OFF = PAGE; // the header and tags fit in the first page with room to spare
/// Pages one request may ask for. A larger read loops; the ring must hold a request plus
/// the worker's read-ahead without lapping itself.
const MAX_REQ = 32;

/// Open `id`'s files on a storage worker and return a reader with the SAME interface as
/// `syncReader` - `paths()`, `size(path)`, `read(path, offset, into)`, `close()` - whose
/// reads come out of the shared page ring. Worker-only, like `syncReader`.
export async function openTitleCached(id) {
  const sab = new SharedArrayBuffer(DATA_OFF + SLOTS * PAGE);
  const h = new Int32Array(sab);
  const worker = new Worker("./storage-worker.js", { type: "module" });
  const ready = await new Promise((resolve, reject) => {
    worker.onmessage = (e) => {
      if (e.data.type === "ready") resolve(e.data);
      else if (e.data.type === "error") reject(new Error(e.data.message));
    };
    worker.onerror = (e) => reject(new Error(`storage worker failed: ${e.message || e}`));
    worker.postMessage({ id, sab });
  });
  // From here the worker reports only failures; a read error is also flagged in `H.ERR`,
  // which is what the synchronous reader can see.
  let workerError = null;
  worker.onmessage = (e) => {
    if (e.data.type === "error") {
      workerError = e.data.message;
      console.error(`[storage] ${e.data.message}`);
    }
  };
  const { paths, sizes } = ready;
  if (ready.openStats) console.log(`[storage] title files ${ready.openStats}`);
  const reader = readerOverRing(sab, paths, sizes, () => workerError);
  return {
    ...reader,
    /// What another worker needs to read the SAME ring (`attachTitleCached`) - the parallel
    /// guest workers of `VITASLOP_SMP` read files themselves instead of forwarding every
    /// read to this worker. Plain data: a SharedArrayBuffer and two arrays.
    share: () => ({ sab, paths, sizes }),
    /// Close the title's files and the storage worker. Resolves once the worker says its
    /// sync handles are CLOSED (or after 2 s, when it is terminated regardless). A caller that
    /// is about to open the same title again - the next device-runner job - has to wait for
    /// this: MEASURED on the phone, a run worker terminated with its storage worker still
    /// nested under it left the handles open for the page's lifetime, and every later run of
    /// that title failed "files are still open in another worker" until every tab was closed.
    close: () =>
      new Promise((resolve) => {
        let done = false;
        const finish = () => {
          if (done) return;
          done = true;
          worker.terminate();
          resolve();
        };
        const timer = setTimeout(finish, 2000);
        worker.addEventListener("message", (e) => {
          if (e.data.type === "closed") {
            clearTimeout(timer);
            finish();
          }
        });
        Atomics.store(h, H.CLOSE, 1);
        Atomics.store(h, H.REQ, 1);
        Atomics.notify(h, H.REQ);
      }),
  };
}

/// A reader over a ring another worker opened (`openTitleCached(..).share()`), with the same
/// `paths`/`size`/`read`/`stats` interface. It owns no storage worker and cannot close one;
/// a storage failure reaches it through the ring's `H.ERR` word. Requests go through the
/// ring's ONE request slot, so every reader of a ring must be serialised by its caller - the
/// emulator reads only inside host calls, under the host lock.
export function attachTitleCached({ sab, paths, sizes }) {
  return readerOverRing(sab, paths, sizes, () => null);
}

function readerOverRing(sab, paths, sizes, workerErrorOf) {
  const h = new Int32Array(sab);
  const data = new Uint8Array(sab, DATA_OFF, SLOTS * PAGE);
  const ids = new Map(paths.map((p, i) => [p, i]));

  const tag = (slot, f) => h[H.TAGS + slot * TAG.STRIDE + f];
  /// Pin the slot holding (pid, page): READY -> PINNED, then re-check the tag, since the
  /// worker may have refilled the slot between the scan and the exchange.
  const pin = (pid, page) => {
    for (let s = 0; s < SLOTS; s++) {
      if (tag(s, TAG.PATH) !== pid + 1 || tag(s, TAG.PAGE) !== page) continue;
      const st = H.TAGS + s * TAG.STRIDE + TAG.STATE;
      if (Atomics.compareExchange(h, st, STATE.READY, STATE.PINNED) !== STATE.READY) continue;
      if (tag(s, TAG.PATH) === pid + 1 && tag(s, TAG.PAGE) === page) return s;
      Atomics.store(h, st, STATE.READY);
    }
    return -1;
  };
  const unpin = (s) => Atomics.store(h, H.TAGS + s * TAG.STRIDE + TAG.STATE, STATE.READY);
  // >>> WHETHER THE READ-AHEAD IS ACTUALLY SERVING ANYTHING.
  //
  // The panel's STORAGE line counts the emulator's read CALLS, and once those calls come out
  // of this ring the count says nothing about what they cost: a hit is a memcpy out of shared
  // memory, a miss is a round trip to another thread with an `Atomics.wait` in the middle, and
  // the line shows the same number either way. A device dump was read with the storage worker
  // live and could not say whether the 16-page read-ahead was working at all, which is the
  // whole claim the worker exists to make. A miss already pays for a thread hop, so timing
  // only the misses adds nothing measurable to the hit path.
  let ringHits = 0;
  let ringMisses = 0;
  let ringWaitMs = 0;
  const request = (pid, page, count) => {
    const t0 = performance.now();
    Atomics.store(h, H.REQ_PATH, pid);
    Atomics.store(h, H.REQ_PAGE, page);
    Atomics.store(h, H.REQ_COUNT, count);
    const seq = Atomics.load(h, H.ACK);
    Atomics.store(h, H.REQ, 1);
    Atomics.notify(h, H.REQ);
    // Bounded waits, so a worker that has died leaves an error rather than a hang.
    let waited = 0;
    while (Atomics.load(h, H.ACK) === seq) {
      const workerError = workerErrorOf();
      if (Atomics.load(h, H.ERR) !== 0 || workerError !== null) {
        throw new Error(`storage worker failed: ${workerError || "read error"}`);
      }
      if (Atomics.wait(h, H.ACK, seq, 1000) === "timed-out" && ++waited >= 30) {
        throw new Error(`storage worker did not answer a read of ${paths[pid]} page ${page} in 30 s`);
      }
    }
    ringWaitMs += performance.now() - t0;
  };

  return {
    paths: () => paths.slice(),
    size: (path) => (ids.has(path) ? sizes[ids.get(path)] : -1),
    read: (path, offset, into) => {
      const pid = ids.get(path);
      if (pid === undefined) return 0;
      const size = sizes[pid];
      let done = 0;
      while (done < into.length) {
        const at = offset + done;
        if (at >= size) break;
        const page = Math.floor(at / PAGE);
        let s = pin(pid, page);
        if (s >= 0) {
          ringHits += 1;
        } else {
          ringMisses += 1;
          const count = Math.min(MAX_REQ, Math.ceil((into.length - done + (at % PAGE)) / PAGE));
          request(pid, page, count);
          s = pin(pid, page);
          if (s < 0) throw new Error(`storage ring did not hold ${path} page ${page} after a request`);
        }
        const from = at - page * PAGE;
        const n = Math.min(into.length - done, tag(s, TAG.LEN) - from);
        if (n <= 0) {
          unpin(s);
          break;
        }
        into.set(data.subarray(s * PAGE + from, s * PAGE + from + n), done);
        unpin(s);
        done += n;
      }
      return done;
    },
    // Read once per panel window, never per read - see ringHits above.
    stats: () => ({ hits: ringHits, misses: ringMisses, waitMs: ringWaitMs }),
  };
}
