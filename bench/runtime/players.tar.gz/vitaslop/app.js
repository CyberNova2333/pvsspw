// The app: a hash router over five screens - library, title, settings, import,
// about - and the player. Plain DOM, no framework; each screen is a function that
// renders into #view and wires its own handlers.

import { ensureIsolation, checkFeatures, canPlay } from "./features.js";
import * as store from "./store.js";
import * as imp from "./import.js";
import * as gamedata from "./gamedata.js";
import { removeTitle, listAddons, removeAddon, setAddonEnabled, readRepatch, setRepatchEnabled, removeRepatch } from "./opfs.js";
import { writeZip, readZip } from "./zipstore.js";
import { createPlayer } from "./player.js";
import { renderVita } from "./vita.js";
import * as navpad from "./navpad.js";

const $ = (id) => document.getElementById(id);
const view = $("view");
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
const go = (hash) => (location.hash = hash);
const fmtDate = (ms) => (ms ? new Date(ms).toLocaleString() : "never");

let features = [];
let playable = false;
const player = createPlayer({
  onExit: () => go(current.titleId ? `#/title/${current.titleId}` : "#/"),
  onRestart: (id, fullscreen) => play(id, fullscreen),
});
let current = { screen: "library", titleId: null };

/// A controller moves around every screen but the game (where gamepad.js has the pad):
/// east is back, start is the settings.
const padPages = () => navpad.attach(document, { onBack: () => history.back(), onStart: () => go("#/settings") });

/// Breadcrumbs: where you are and the way back. Every screen under a title carries them.
function crumbs(parts) {
  return `<nav class="crumbs">${parts
    .map((p, i) => (i === parts.length - 1 || !p.href ? `<span>${esc(p.text)}</span>` : `<a href="${esc(p.href)}">${esc(p.text)}</a>`))
    .join('<span class="sep">/</span>')}</nav>`;
}

/// The leaves of `mine` that differ from `base`: nested objects recurse, so a title that
/// remaps one key stores one key, and every other global change still reaches it.
function deepDiff(base, mine) {
  const out = {};
  for (const k of new Set([...Object.keys(base || {}), ...Object.keys(mine || {})])) {
    const b = base ? base[k] : undefined;
    const m = mine ? mine[k] : undefined;
    const isObj = (v) => v && typeof v === "object" && !Array.isArray(v);
    if (isObj(b) && isObj(m)) {
      const d = deepDiff(b, m);
      if (Object.keys(d).length) out[k] = d;
    } else if (m === undefined) {
      out[k] = null;
    } else if (JSON.stringify(b) !== JSON.stringify(m)) out[k] = m;
  }
  return out;
}
const leafPaths = (o, prefix = "") => Object.entries(o || {}).flatMap(([k, v]) => (v && typeof v === "object" ? leafPaths(v, prefix + k + ".") : [prefix + k]));

// ------------------------------- router -------------------------------

function route() {
  const h = location.hash || "#/";
  const m = h.match(/^#\/(title|settings|play|import|about)?\/?([A-Za-z0-9_-]*)/);
  const screen = (m && m[1]) || "library";
  const id = (m && m[2]) || null;
  if (player.isRunning() && screen !== "play") player.stop();
  // A NEW object per route: a renderer that is still awaiting when the screen has
  // moved on (a controller's back is quick) sees `current` change and must not write.
  current = { screen, titleId: id };
  const me = current;
  document.body.dataset.screen = screen;
  if (screen === "play") navpad.detach();
  else padPages();
  const names = { library: "Library", settings: "Settings", import: id ? "Add add-ons" : "Add games", about: "About" };
  document.title = names[screen] ? `${names[screen]} - vitaslop` : "vitaslop";
  const fn = { library: renderLibrary, title: renderTitle, settings: renderSettings, import: renderImport, about: renderAbout, play: renderPlay }[screen];
  fn(id).catch((e) => {
    if (current !== me) return;
    view.innerHTML = `<div class="card error"><h2>Something went wrong</h2><pre>${esc(e && e.stack ? e.stack : e)}</pre></div>`;
  });
}
window.addEventListener("hashchange", route);
/// True once the router has moved on from the screen `me` was rendering.
const stale = (me) => current !== me;

// ------------------------------- library -------------------------------

/// A rePatch overlay import outlives the page that started it: the title page can be redrawn
/// (or left and come back to) while the worker copies, so its state is kept per title here and
/// whichever title page is showing draws it. `{ busy, note }`.
const repatchJobs = new Map();
/// The showing title page's overlay card redraw, so a finished import can refresh it.
let repatchCard = null;

let sortMode = "recent";
let query = "";

async function renderLibrary() {
  const me = current;
  const titles = await store.listTitles();
  if (stale(me)) return;
  view.innerHTML = `
    <div class="toolbar">
      <input id="search" type="search" placeholder="Search ${titles.length} title${titles.length === 1 ? "" : "s"}" value="${esc(query)}" autocomplete="off" />
      <select id="sort" title="Sort">
        <option value="recent">Recently added</option>
        <option value="played">Recently played</option>
        <option value="name">Name</option>
        <option value="id">Title id</option>
      </select>
      <a class="btn primary" href="#/import">Add games</a>
    </div>
    ${playable ? "" : browserBlock()}
    <div id="grid" class="grid"></div>
    ${titles.length ? "" : `<div class="empty"><p>No titles yet.</p><p><a class="btn primary" href="#/import">Add a game</a> from a .pkg and work.bin, a dumped folder, or a zip of either.</p></div>`}`;
  $("sort").value = sortMode;
  const grid = $("grid");
  const draw = () => {
    const q = query.trim().toLowerCase();
    let list = titles.filter((t) => !q || `${t.title} ${t.titleId} ${t.contentId}`.toLowerCase().includes(q));
    const by = {
      recent: (a, b) => (b.importedAt || 0) - (a.importedAt || 0),
      played: (a, b) => (b.lastPlayedAt || 0) - (a.lastPlayedAt || 0) || (b.importedAt || 0) - (a.importedAt || 0),
      name: (a, b) => a.title.localeCompare(b.title),
      id: (a, b) => a.titleId.localeCompare(b.titleId),
    }[sortMode];
    list.sort(by);
    grid.innerHTML = list
      .map(
        (t) => `<a class="tile" href="#/title/${esc(t.titleId)}" data-id="${esc(t.titleId)}" title="${esc(t.title)}">
          <span class="icon"><img alt="" data-icon="${esc(t.titleId)}" /></span>
          <span class="name">${esc(t.title)}</span>
          <span class="id">${esc(t.titleId)}</span></a>`
      )
      .join("");
    lazyIcons(grid);
  };
  draw();
  $("search").addEventListener("input", (e) => {
    query = e.target.value;
    draw();
  });
  $("sort").addEventListener("change", (e) => {
    sortMode = e.target.value;
    draw();
  });
}

/// Icons load as tiles scroll into view: a thousand titles is a thousand files, and
/// the library must open instantly regardless.
function lazyIcons(root) {
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (!e.isIntersecting) continue;
        const img = e.target;
        io.unobserve(img);
        store.titleImage(img.dataset.icon).then((url) => {
          if (url) img.src = url;
          else img.closest(".icon").classList.add("noicon");
        });
      }
    },
    { rootMargin: "300px" }
  );
  for (const img of root.querySelectorAll("img[data-icon]")) io.observe(img);
}

function browserBlock() {
  const bad = features.filter((f) => f.level === "fatal");
  return `<div class="card error"><h2>This browser cannot run titles here</h2>
    <ul class="checks">${bad.map((f) => `<li><b>${esc(f.text)}</b><br>${esc(f.fix)}</li>`).join("")}</ul>
    <p><a href="#/about">All checks</a></p></div>`;
}

// ------------------------------- title -------------------------------

async function renderTitle(id) {
  const me = current;
  const meta = await store.readTitle(id);
  if (stale(me)) return;
  if (!meta) {
    view.innerHTML = `<div class="card"><h2>${esc(id)}</h2><p>This title is not in the library.</p><p><a class="btn" href="#/import">Add it</a></p></div>`;
    return;
  }
  // >>> THE PAGE DRAWS BEFORE THE SETTINGS RESOLVE. `store.effective` runs in the emulator
  // bundle (the settings logic is its Rust), and the first call of a page session loads and
  // compiles all of it on this thread - the second or so the title page used to hang for. Only
  // the profile name, Play and the saved-data buttons depend on it, so those wait and nothing
  // else does. (The app also starts that load in the background at start-up - see `boot`.)
  const effP = store.effective(id);
  document.title = `${meta.title} - vitaslop`;
  // The size is NOT awaited here: it can take a moment the first time (see `store.titleBytes`)
  // and nothing else on the page depends on it, so the page draws first and the size fills in.
  const [icon, pic] = await Promise.all([store.titleImage(id), store.titleImage(id, "pic0.png")]);
  if (stale(me)) return;
  let bytes = typeof meta.storedBytes === "number" ? meta.storedBytes : null;
  const sizeText = () => (bytes == null ? "size..." : store.fmtBytes(bytes));
  view.innerHTML = `
    ${crumbs([{ text: "Library", href: "#/" }, { text: meta.title }])}
    <div class="hero">
      <div class="hero-in">
        <span class="icon big ${icon ? "" : "noicon"}">${icon ? `<img src="${icon}" alt="" />` : ""}</span>
        <div class="hero-text">
          <h1>${esc(meta.title)}</h1>
          <p class="meta">${esc(meta.titleId)}${meta.appVersion ? " &middot; v" + esc(meta.appVersion) : ""} &middot; <span id="t-size">${sizeText()}</span> &middot; added ${fmtDate(meta.importedAt)} &middot; played ${fmtDate(meta.lastPlayedAt)}</p>
          <div class="actions">
            <button id="play" class="btn primary big" disabled>Play</button>
            <a class="btn" href="#/settings/${esc(id)}">Settings for this title</a>
            <button id="remove" class="btn danger">Remove</button>
          </div>
        </div>
      </div>
    </div>
    ${playable ? "" : browserBlock()}
    <div class="card">
      <h2>Saved data <span class="dim">profile: <span id="gd-profile">...</span></span></h2>
      <p id="gd-info" class="dim">checking...</p>
      <div class="actions">
        <button id="gd-dl" class="btn" disabled>Download</button>
        <button id="gd-up" class="btn" disabled>Upload</button>
        <button id="gd-rm" class="btn danger" disabled>Clear</button>
        <input id="gd-file" type="file" accept=".zip,application/zip" hidden />
      </div>
      <p class="dim">What the game saved - its save files and trophies - and nothing of the game itself. A download is a file you own; upload it on another device to continue there.</p>
    </div>
    <div class="card">
      <h2>Add-ons <span class="dim" id="ad-count"></span></h2>
      <ul id="ad-list" class="addons"></ul>
      <p id="ad-none" class="dim" hidden>None installed. Add-ons you own for this game - costumes, tracks, characters - come in the same .pkg + work.bin, folder or zip a game does, and the game finds them the next time it starts.</p>
      <div class="actions"><a class="btn" href="#/import/${esc(id)}">Add add-ons</a></div>
    </div>
    <div class="card">
      <h2>rePatch overlay</h2>
      <ul id="rp-list" class="addons"></ul>
      <p id="rp-none" class="dim" hidden>None. An overlay lays your own modified or decrypted files over this game, as the rePatch plugin does on a Vita: pick a folder or .zip laid out like ux0:rePatch/${esc(id)}/ (a reAddcont/${esc(id)}/ folder beside it covers add-ons). Executables in it must be decrypted. The game itself is never changed - turn the overlay off or remove it here.</p>
      <p id="rp-note" class="dim" hidden></p>
      <div class="actions">
        <button id="rp-dir" class="btn">Add from a folder</button>
        <button id="rp-zip" class="btn">Add from a .zip</button>
        <input id="rp-dir-in" type="file" webkitdirectory hidden />
        <input id="rp-zip-in" type="file" accept=".zip,application/zip" hidden />
      </div>
    </div>`;
  // The backdrop goes on through the element's style property: a `style="..."` attribute
  // in the markup is an inline style the page's Content-Security-Policy refuses.
  if (pic) view.querySelector(".hero").style.backgroundImage = `url('${pic}')`;
  if (bytes == null) {
    store.titleBytes(id).then((n) => {
      bytes = n;
      if (!stale(me) && $("t-size")) $("t-size").textContent = sizeText();
    });
  }
  let addons = [];
  const drawAddons = async () => {
    addons = await listAddons(id);
    if (stale(me) || !$("ad-list")) return;
    $("ad-count").textContent = addons.length ? `${addons.length} installed` : "";
    $("ad-none").hidden = addons.length > 0;
    $("ad-list").innerHTML = addons
      .map(
        (a) => `<li><div><b>${esc(a.title)}</b><br><span class="dim">${esc(a.dir)}${a.version ? " &middot; v" + esc(a.version) : ""} &middot; ${store.fmtBytes(a.bytes)} &middot; added ${fmtDate(a.importedAt)}</span></div>
          <label class="row"><input type="checkbox" data-addon-on="${esc(a.dir)}" ${a.disabled ? "" : "checked"} /><span>On</span></label>
          <button class="btn danger" data-addon="${esc(a.dir)}">Remove</button></li>`
      )
      .join("");
    // Off keeps the add-on; the game does not see it until it is on again.
    for (const c of $("ad-list").querySelectorAll("input[data-addon-on]")) {
      c.addEventListener("change", async () => {
        try {
          await setAddonEnabled(id, c.dataset.addonOn, c.checked);
        } catch (err) {
          alert(`Not changed: ${err.message || err}`);
        }
        drawAddons();
      });
    }
    for (const b of $("ad-list").querySelectorAll("button[data-addon]")) {
      b.addEventListener("click", async () => {
        const a = addons.find((x) => x.dir === b.dataset.addon);
        if (!a || !confirm(`Remove the add-on ${a.title} from ${meta.title}?\n\nThe game will not see it the next time it starts. Saved data is kept.`)) return;
        try {
          await removeAddon(id, a.dir);
        } catch (err) {
          alert(`Not removed: ${err.message || err}`);
        }
        drawAddons();
      });
    }
  };
  drawAddons();
  // The rePatch overlay (see opfs.js): one per title, switched, replaced or removed here.
  const job = () => repatchJobs.get(id) || { busy: false, note: "" };
  const rpNote = (text) => {
    repatchJobs.set(id, { ...job(), note: text || "" });
    if (repatchCard && repatchCard.id === id) repatchCard.draw();
  };
  const drawRepatch = async () => {
    const rp = await readRepatch(id);
    if (stale(me) || !$("rp-list")) return;
    const { busy, note } = job();
    $("rp-note").hidden = !note;
    $("rp-note").textContent = note;
    $("rp-none").hidden = !!rp;
    $("rp-dir").textContent = rp ? "Replace with a folder" : "Add from a folder";
    $("rp-zip").textContent = rp ? "Replace with a .zip" : "Add from a .zip";
    $("rp-dir").disabled = $("rp-zip").disabled = busy;
    if (!rp) {
      $("rp-list").innerHTML = "";
      return;
    }
    const code = rp.code && rp.code.length ? `replaces ${rp.code.map(esc).join(", ")}` : "data only";
    const addcont = rp.addcont && rp.addcont.length ? ` &middot; add-ons ${rp.addcont.map(esc).join(", ")}` : "";
    // Where the files went: over the game, over add-ons - and any folder whose place was INFERRED
    // (a bare pack names no rePatch/reAddcont folder), with why.
    const split = rp.appFiles !== undefined ? ` &middot; ${rp.appFiles} over the game, ${rp.files - rp.appFiles} over add-ons` : "";
    const inferred = rp.inferred && rp.inferred.length ? `<br><span class="dim">${rp.inferred.map(esc).join("<br>")}</span>` : "";
    $("rp-list").innerHTML = `<li><div><b>${esc(rp.source || "Overlay")}</b><br><span class="dim">${rp.files} files${split} &middot; ${store.fmtBytes(rp.bytes)} &middot; ${code}${addcont} &middot; added ${fmtDate(rp.importedAt)}</span>${inferred}</div>
      <label class="row"><input type="checkbox" id="rp-on" ${rp.disabled ? "" : "checked"} /><span>On</span></label>
      <button class="btn danger" id="rp-rm">Remove</button></li>`;
    $("rp-on").addEventListener("change", async () => {
      try {
        await setRepatchEnabled(id, $("rp-on").checked);
      } catch (err) {
        alert(`Not changed: ${err.message || err}`);
      }
      drawRepatch();
    });
    $("rp-rm").addEventListener("click", async () => {
      if (!confirm(`Remove the rePatch overlay from ${meta.title}?\n\nIts files are deleted; the game itself is untouched and runs without it from the next start. To keep it, turn it off instead.`)) return;
      await removeRepatch(id);
      rpNote("");
      drawRepatch();
    });
  };
  const addRepatch = async (entries, pickedRoot, source) => {
    if (!entries.length || job().busy) return;
    repatchJobs.set(id, { busy: true, note: "Reading..." });
    drawRepatch();
    try {
      const r = await imp.runRepatch(entries, id, { pickedRoot, source }, (p) => {
        if (p.total && p.unit !== "files") rpNote(`Copying ${p.file} - ${Math.floor((p.done * 100) / p.total)}%`);
      });
      const left = r.ignored ? ` ${r.ignored} file(s) outside the overlay were left out.` : "";
      rpNote(`Overlay added. It applies the next time the game starts.${left}`);
    } catch (err) {
      rpNote(`Could not add the overlay: ${err.message || err}`);
    }
    repatchJobs.set(id, { ...job(), busy: false });
    if (repatchCard && repatchCard.id === id) repatchCard.draw();
  };
  $("rp-dir").addEventListener("click", () => $("rp-dir-in").click());
  $("rp-zip").addEventListener("click", () => $("rp-zip-in").click());
  $("rp-dir-in").addEventListener("change", (e) => {
    const entries = imp.entriesFromFiles(e.target.files);
    const source = entries.length ? entries[0].path.split("/")[0] : "";
    addRepatch(entries, true, source);
  });
  $("rp-zip-in").addEventListener("change", (e) => {
    const f = e.target.files[0];
    if (f) addRepatch([{ path: f.name, file: f }], false, f.name);
  });
  repatchCard = { id, draw: drawRepatch };
  drawRepatch();
  $("remove").addEventListener("click", async () => {
    const withAddons = addons.length ? ` and its ${addons.length} add-on${addons.length === 1 ? "" : "s"}` : "";
    const withOverlay = (await readRepatch(id)) ? " and its rePatch overlay" : "";
    if (!confirm(`Remove ${meta.title} (${meta.titleId}) from this browser?\n\nThis deletes the imported game (${sizeText()})${withAddons}${withOverlay} and its prepared code. Saved data is kept; clear it separately if you want it gone.`)) return;
    await removeTitle(id);
    await store.removeTitleRecord(id);
    go("#/");
  });
  const eff = await effP;
  if (stale(me)) return;
  gamedata.setProfile(eff.profile);
  $("gd-profile").textContent = eff.profile;
  $("play").disabled = !playable;
  $("gd-up").disabled = false;
  $("play").addEventListener("click", () => {
    // Inside the tap, before any await - see `askFullscreenNow`.
    const full = wantsFullscreen(eff);
    if (full) player.askFullscreenNow();
    play(id, full);
  });
  const info = $("gd-info");
  const refresh = async () => {
    const i = await gamedata.info(id);
    $("gd-dl").disabled = $("gd-rm").disabled = !i;
    info.textContent = i ? `${store.fmtBytes(i.bytes)}, last written ${fmtDate(i.modified)}` : "nothing saved yet - it appears here the first time the game saves.";
  };
  refresh();
  $("gd-dl").addEventListener("click", async () => {
    const b = await gamedata.read(id);
    if (b) downloadBytes(`vitaslop-${id}-${eff.profile}-gamedata.zip`, b);
  });
  $("gd-up").addEventListener("click", () => $("gd-file").click());
  $("gd-file").addEventListener("change", async (e) => {
    const f = e.target.files && e.target.files[0];
    e.target.value = "";
    if (!f) return;
    try {
      const bytes = new Uint8Array(await f.arrayBuffer());
      const summary = await describeGameData(bytes.slice().buffer);
      const existing = await gamedata.info(id);
      if (!confirm(`Restore this save into ${meta.title}?\n\n${summary}${existing ? `\n\nThis REPLACES the ${store.fmtBytes(existing.bytes)} already saved.` : ""}`)) return;
      await gamedata.write(id, bytes);
    } catch (err) {
      alert(`Not restored: ${err.message || err}`);
    }
    refresh();
  });
  $("gd-rm").addEventListener("click", async () => {
    const i = await gamedata.info(id);
    if (!i || !confirm(`Delete the saved data for ${meta.title}? This cannot be undone.`)) return;
    await gamedata.clear(id);
    refresh();
  });
}

const describeGameData = (zip) =>
  new Promise((resolve, reject) => {
    const w = new Worker("./gamedata-worker.js", { type: "module" });
    w.onmessage = (e) => {
      w.terminate();
      e.data.ok ? resolve(e.data.summary) : reject(new Error(e.data.error));
    };
    w.onerror = (e) => {
      w.terminate();
      reject(new Error(e.message || "the game-data worker failed to start"));
    };
    w.postMessage({ zip }, [zip]);
  });

function downloadBytes(name, bytes, type = "application/zip") {
  const url = URL.createObjectURL(new Blob([bytes], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 10000);
}

// ------------------------------- play -------------------------------

/// Whether pressing Play should take over the screen. `auto` is the shipped answer -
/// a touch screen has no room to spare and a desktop browser has other tabs - and the
/// setting exists because that is a preference, not a fact about the device.
const wantsFullscreen = (eff) =>
  eff.fullscreenOnStart === "always" || (eff.fullscreenOnStart !== "never" && matchMedia("(pointer: coarse)").matches);

async function play(id, fullscreen) {
  const meta = await store.readTitle(id);
  if (!meta || !playable) return;
  const eff = await store.effective(id);
  current = { screen: "play", titleId: id };
  history.replaceState(null, "", `#/play/${id}`);
  document.body.dataset.screen = "play";
  navpad.detach();
  view.innerHTML = "";
  await player.start(meta, eff, {
    fullscreen,
    onSetting: (patch) => saveRuntimeSetting(id, patch),
  });
}

/// A change made from the in-game menu is kept where that setting already lives: in the title's
/// patch when this title overrides it, else in the global record. Saved globally regardless, a
/// title override would win again at the next launch and the change would silently not stick.
function saveRuntimeSetting(id, patch) {
  const mine = store.titleSettings(id);
  const toTitle = {};
  const toGlobal = {};
  const split = (p, t, title, global) => {
    for (const [k, v] of Object.entries(p)) {
      if (!t || !(k in t)) global[k] = v;
      else if (v && typeof v === "object" && !Array.isArray(v) && t[k] && typeof t[k] === "object") {
        title[k] = {};
        global[k] = {};
        split(v, t[k], title[k], global[k]);
      } else title[k] = v;
    }
  };
  split(patch, mine, toTitle, toGlobal);
  const prune = (o) => {
    for (const [k, v] of Object.entries(o)) if (v && typeof v === "object" && !Array.isArray(v) && !Object.keys(prune(v)).length) delete o[k];
    return o;
  };
  if (Object.keys(prune(toTitle)).length) store.saveTitleSettings(id, deepMerge(mine, toTitle));
  if (Object.keys(prune(toGlobal)).length) store.saveGlobalSettings(deepMerge(store.globalSettings(), toGlobal));
}

async function renderPlay(id) {
  if (player.isRunning()) return;
  // Arrived by URL (a reload, a link): there is no gesture, so the browser will not let
  // audio start and fullscreen cannot be asked for. Land on the title page instead,
  // where the Play button is.
  go(id ? `#/title/${id}` : "#/");
}

function deepMerge(a, b) {
  const out = { ...a };
  for (const [k, v] of Object.entries(b)) {
    out[k] = v && typeof v === "object" && !Array.isArray(v) && out[k] && typeof out[k] === "object" ? deepMerge(out[k], v) : v;
  }
  return out;
}

// ------------------------------- settings -------------------------------

async function renderSettings(id) {
  const me = current;
  const vocab = await store.vocabulary();
  const global = await store.effective(null);
  const eff = id ? await store.effective(id) : global;
  const meta = id ? await store.readTitle(id) : null;
  const profiles = await gamedata.listProfiles();
  if (stale(me)) return;
  if (!profiles.includes(eff.profile)) profiles.push(eff.profile);
  const knobsText = Object.entries(eff.knobs).map(([k, v]) => `${k}=${v}`).join("\n");
  const opt = (v, cur, label) => `<option value="${esc(v)}" ${v === cur ? "selected" : ""}>${esc(label ?? v)}</option>`;

  if (meta) document.title = `${meta.title} settings - vitaslop`;
  const patch = id ? store.titleSettings(id) : {};
  const overridden = new Set(leafPaths(patch));
  const kb = { ...eff.keyboard };
  const gp = { ...eff.gamepad };
  let ctlMode = "keyboard";
  view.innerHTML = `
    ${meta ? crumbs([{ text: "Library", href: "#/" }, { text: meta.title, href: `#/title/${id}` }, { text: "Settings" }]) : crumbs([{ text: "Library", href: "#/" }, { text: "Settings" }])}
    <h1>${meta ? `Settings for ${esc(meta.title)}` : "Settings"}</h1>
    ${meta ? `<p class="dim">Only what you change here is kept for this title (marked <b class="ov">changed</b>); everything else follows the <a href="#/settings">global settings</a>, including later changes to them.</p>` : ""}
    <form id="sf" class="settings">
      <section class="card"><h2>General</h2>
        <label class="row"><input type="checkbox" name="pauseOnBlur" ${eff.pauseOnBlur ? "checked" : ""} /><span>Pause when this page is hidden or loses focus<small>Not the game's pause menu: the emulator stops, as a console in a pocket would.</small></span></label>
        <label class="row"><input type="checkbox" name="showFps" ${eff.showFps ? "checked" : ""} /><span>Show the frame rate over the game</span></label>
        <label class="row"><span>Scaling</span><select name="scaling">${opt("fit", eff.scaling, "Fit (smooth)")}${opt("integer", eff.scaling, "Integer (crisp)")}${opt("stretch", eff.scaling, "Stretch")}</select></label>
        <label class="row"><span>Start in fullscreen<small>Automatic takes over the screen on a touch device and plays in the page on a desktop. The in-game menu toggles it either way.</small></span><select name="fullscreenOnStart">${opt("auto", eff.fullscreenOnStart, "Automatic (touch screens)")}${opt("always", eff.fullscreenOnStart, "Always")}${opt("never", eff.fullscreenOnStart, "Never")}</select></label>
        <label class="row"><input type="checkbox" name="lockLandscape" ${eff.lockLandscape ? "checked" : ""} /><span>Hold the screen in landscape<small>Touch devices, in fullscreen. Off, the game turns with the device and the controls move below it in portrait.</small></span></label>
        <label class="row"><span>Save profile<small>Each profile keeps its own saved data for every game.</small></span>
          <span class="inline"><select name="profile">${profiles.map((p) => opt(p, eff.profile)).join("")}</select><button type="button" id="new-profile" class="btn small">New</button></span></label>
      </section>
      <section class="card"><h2>On-screen controls</h2>
        <p class="dim">The buttons and sticks drawn around the game. They also light up when a keyboard or gamepad presses the same button.</p>
        <label class="row"><span>Placement<small>Automatic shows them only on a touch screen: over the game in landscape, below it in portrait. Hidden on a desktop with a mouse; pick a placement to show them anyway.</small></span><select name="pad.mode">${opt("auto", eff.pad.mode, "Automatic")}${opt("overlay", eff.pad.mode, "Over the game")}${opt("beside", eff.pad.mode, "Beside the game")}${opt("hidden", eff.pad.mode, "Hidden")}</select></label>
        <label class="row"><span>Opacity over the game</span><input type="range" name="pad.opacity" min="0.1" max="1" step="0.05" value="${eff.pad.opacity}" /></label>
        <label class="row"><span>Size</span><input type="range" name="pad.scale" min="0.6" max="1.6" step="0.05" value="${eff.pad.scale}" /></label>
        <label class="row"><input type="checkbox" name="pad.vibrate" ${eff.pad.vibrate ? "checked" : ""} /><span>Vibrate on press</span></label>
        <label class="row"><input type="checkbox" name="rearTouch" ${eff.rearTouch ? "checked" : ""} /><span>Rear touch panel<small>For the few games that use the back of the console. With a mouse, drag with the RIGHT button; on a touch screen, a REAR button joins Start and Select, and while it is lit your touches on the game go to the rear panel.</small></span></label>
        <label class="row"><span>Stick dead zone</span><input type="range" name="stickDeadzone" min="0" max="0.5" step="0.01" value="${eff.stickDeadzone}" /></label>
      </section>
      <section class="card" id="controls"><h2>Controls</h2>
        <div class="seg"><button type="button" class="on" data-ctl="keyboard">Keyboard</button><button type="button" data-ctl="gamepad">Gamepad</button></div>
        <p class="dim" id="ctl-hint">Click a control on the picture, then press the key for it.</p>
        <div id="vita"></div>
        <div class="actions"><button type="button" id="ctl-reset" class="btn small">Reset to defaults</button></div>
        <p class="dim">In a game, a controller's home button (button 16 where the pad and browser expose one) opens the menu; so does holding Start and Select together for a second, on any pad. Outside a game the controller moves around this site: the d-pad or left stick moves, the south button (A or Cross) picks, the east button (B or Circle) goes back, Start (Options) opens the settings, and left/right change a choice, checkbox or slider.</p>
      </section>
      <details class="card"><summary><h2>Advanced</h2></summary>
        <label class="col"><span>Knobs<small>One VITASLOP_NAME=value per line. The browser has no environment; this is the only way to reach one.</small></span><textarea name="knobs" rows="4" spellcheck="false">${esc(knobsText)}</textarea></label>
        <label class="row"><span>Fast-forward to frame<small>Runs unpaced and unpresented to here first.</small></span><input type="number" name="fastForward" min="0" step="100" value="${eff.fastForward}" /></label>
        <label class="row"><input type="checkbox" name="debugCapture" ${eff.debugCapture ? "checked" : ""} /><span>Capture debug timings<small>Times every host call for the diagnostics; roughly doubles the frame cost.</small></span></label>
        <label class="row"><input type="checkbox" name="consoleNotes" ${eff.consoleNotes ? "checked" : ""} /><span>Mirror run notes to the console</span></label>
      </details>
      <div class="actions sticky">
        <button type="submit" class="btn primary">Save</button>
        ${meta ? `<button type="button" id="reset-title" class="btn">Use global settings</button>` : `<button type="button" id="reset-all" class="btn">Reset to defaults</button>`}
        <span id="saved" class="dim"></span>
      </div>
    </form>
    ${meta ? "" : `
    <section class="card"><h2>Saved data</h2>
      <p class="dim">Every game's saved data in the current profile, as one file.</p>
      <div class="actions"><button id="gd-all-dl" class="btn">Download all</button><button id="gd-all-up" class="btn">Upload a bundle</button><button id="gd-all-rm" class="btn danger">Clear all</button><input id="gd-all-file" type="file" accept=".zip" hidden /></div>
      <p id="gd-all-info" class="dim"></p>
    </section>
    <section class="card"><h2>Storage</h2><p id="storage" class="dim">measuring...</p></section>
    <section class="card"><h2>This browser</h2>${featureList()}</section>`}`;

  const form = $("sf");
  const read = () => {
    const fd = new FormData(form);
    return {
      pauseOnBlur: form.pauseOnBlur.checked,
      showFps: form.showFps.checked,
      fpsInTitle: eff.fpsInTitle,
      scaling: fd.get("scaling"),
      fullscreenOnStart: fd.get("fullscreenOnStart"),
      lockLandscape: form.lockLandscape.checked,
      pad: { mode: fd.get("pad.mode"), opacity: Number(fd.get("pad.opacity")), scale: Number(fd.get("pad.scale")), vibrate: form["pad.vibrate"].checked },
      keyboard: { ...kb },
      gamepad: { ...gp },
      stickDeadzone: Number(fd.get("stickDeadzone")),
      rearTouch: form.rearTouch.checked,
      profile: fd.get("profile"),
      knobs: knobsFromText(fd.get("knobs")),
      fastForward: Number(fd.get("fastForward")) || 0,
      debugCapture: form.debugCapture.checked,
      consoleNotes: form.consoleNotes.checked,
    };
  };
  const knobsFromText = (t) => {
    const out = {};
    for (const line of String(t || "").split(/\r?\n/)) {
      const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(line);
      if (m) out[m[1]] = m[2];
    }
    return out;
  };
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const v = read();
    if (meta) {
      // Only the LEAVES that differ from the global settings are the title's own.
      store.saveTitleSettings(id, deepDiff(global, v));
    } else store.saveGlobalSettings(v);
    $("saved").textContent = "saved";
    setTimeout(() => ($("saved").textContent = ""), 1500);
  });
  if (meta) $("reset-title").addEventListener("click", () => {
    store.saveTitleSettings(id, null);
    renderSettings(id);
  });
  else $("reset-all").addEventListener("click", () => {
    if (!confirm("Reset every global setting to its default?")) return;
    store.saveGlobalSettings({});
    renderSettings(null);
  });
  $("new-profile").addEventListener("click", () => {
    const name = prompt("Profile name (letters, digits, - and _):");
    if (!name || !/^[A-Za-z0-9_-]{1,32}$/.test(name)) return;
    const sel = form.profile;
    if (![...sel.options].some((o) => o.value === name)) sel.add(new Option(name, name));
    sel.value = name;
  });
  const drawVita = () => {
    $("ctl-hint").textContent = ctlMode === "keyboard" ? "Click a control on the picture, then press the key for it." : "Standard layout positions: south is the bottom face button (A or Cross), east the right one (B or Circle).";
    renderVita($("vita"), {
      buttons: vocab.buttons,
      controls: vocab.gamepadControls,
      keyboard: kb,
      gamepad: gp,
      mode: ctlMode,
      onKey: (name, code) => (kb[name] = code),
      onPad: (name, control) => (gp[name] = control),
    });
  };
  drawVita();
  for (const b of view.querySelectorAll("#controls .seg button")) {
    b.addEventListener("click", () => {
      ctlMode = b.dataset.ctl;
      for (const o of view.querySelectorAll("#controls .seg button")) o.classList.toggle("on", o === b);
      drawVita();
    });
  }
  $("ctl-reset").addEventListener("click", async () => {
    const d = await store.defaults();
    Object.assign(kb, d.keyboard);
    Object.assign(gp, d.gamepad);
    drawVita();
  });
  // Mark what this title overrides.
  for (const el of form.querySelectorAll("[name]")) {
    const key = el.name.replace(/^gamepad\./, "gamepad.");
    if ([...overridden].some((o) => o === key || o.startsWith(key + "."))) el.closest("label")?.classList.add("overridden");
  }
  if ([...overridden].some((o) => o.startsWith("keyboard.") || o.startsWith("gamepad."))) $("controls").classList.add("overridden");

  if (!meta) {
    gamedata.setProfile(eff.profile);
    // The tails below land after an await; by then the screen may have moved on (a
    // controller's back is quick), and a write to a null element here would surface as
    // the router's "Something went wrong" card over the NEW screen.
    const refreshAll = async () => {
      const ids = await gamedata.listSaved();
      if (!$("gd-all-info")) return;
      $("gd-all-info").textContent = ids.length ? `${ids.length} game${ids.length === 1 ? "" : "s"} have saved data in profile "${eff.profile}".` : `no saved data in profile "${eff.profile}".`;
      $("gd-all-dl").disabled = $("gd-all-rm").disabled = !ids.length;
    };
    refreshAll();
    $("gd-all-dl").addEventListener("click", async () => {
      const entries = [];
      for (const tid of await gamedata.listSaved()) entries.push({ name: `${tid}.zip`, bytes: await gamedata.read(tid) });
      downloadBytes(`vitaslop-${eff.profile}-all-gamedata.zip`, writeZip(entries));
    });
    $("gd-all-up").addEventListener("click", () => $("gd-all-file").click());
    $("gd-all-file").addEventListener("change", async (e) => {
      const f = e.target.files && e.target.files[0];
      e.target.value = "";
      if (!f) return;
      try {
        const entries = readZip(new Uint8Array(await f.arrayBuffer())).filter((x) => /^[A-Za-z0-9_-]+\.zip$/.test(x.name));
        if (!entries.length) throw new Error("no <TITLE_ID>.zip entries in this bundle");
        if (!confirm(`Restore saved data for ${entries.length} game${entries.length === 1 ? "" : "s"} into profile "${eff.profile}"? Existing saves for the same games are replaced.`)) return;
        for (const x of entries) await gamedata.write(x.name.slice(0, -4), x.bytes);
      } catch (err) {
        alert(`Not restored: ${err.message || err}`);
      }
      refreshAll();
    });
    $("gd-all-rm").addEventListener("click", async () => {
      const ids = await gamedata.listSaved();
      if (!ids.length || !confirm(`Delete the saved data of ${ids.length} game${ids.length === 1 ? "" : "s"} in profile "${eff.profile}"? This cannot be undone.`)) return;
      for (const tid of ids) await gamedata.clear(tid);
      refreshAll();
    });
    let storageText;
    try {
      const est = await navigator.storage.estimate();
      storageText = `${store.fmtBytes(est.usage)} used of ${store.fmtBytes(est.quota)} this browser will give this site.`;
    } catch {
      storageText = "this browser does not report storage use.";
    }
    if ($("storage")) $("storage").textContent = storageText;
  }
}

function featureList() {
  return `<ul class="checks">${features.map((f) => `<li class="${f.level}"><b>${esc(f.text)}</b>${f.level !== "ok" && f.fix ? `<br>${esc(f.fix)}` : ""}</li>`).join("")}</ul>`;
}

// ------------------------------- import -------------------------------

/// The import screen. With `addonFor` (a title id: `#/import/<id>`) it adds ADD-ONS to that
/// title instead of games to the library - the same pickers and the same containers, filed
/// under the title rather than beside it.
async function renderImport(addonFor) {
  const me = current;
  const owner = addonFor ? await store.readTitle(addonFor) : null;
  if (stale(me)) return;
  if (addonFor && !owner) {
    view.innerHTML = `<div class="card"><h2>${esc(addonFor)}</h2><p>This title is not in the library, so it cannot take add-ons.</p><p><a class="btn" href="#/">Library</a></p></div>`;
    return;
  }
  const what = addonFor ? "add-on" : "game";
  view.innerHTML = `
    ${addonFor ? crumbs([{ text: "Library", href: "#/" }, { text: owner.title, href: `#/title/${addonFor}` }, { text: "Add add-ons" }]) : ""}
    <h1>${addonFor ? `Add add-ons to ${esc(owner.title)}` : "Add games"}</h1>
    <p class="own">vitaslop only works with games ${addonFor ? "and add-ons " : ""}you own, from your own console. It provides no games and downloads nothing.</p>
    <div class="tabs" id="tabs">
      <button class="tab on" data-mode="pkg">Package (.pkg + work.bin)</button>
      <button class="tab" data-mode="folder">Dumped folder</button>
      <button class="tab" data-mode="zip">Zip</button>
      ${addonFor ? "" : `<button class="tab" data-mode="vpk">Homebrew (.vpk)</button>`}
    </div>
    <div class="card mode" id="mode-pkg">
      <p class="dim">A ${what}'s <code>.pkg</code> from a console and the <code>work.bin</code> licence that was made for it (from NoNpDrm or a dump). Both are needed: the pkg is encrypted and the licence holds its key.</p>
      <label class="pick"><span>1. The package</span><span class="inline"><button id="pick-pkg" class="btn">Choose .pkg</button><span id="pkg-name" class="dim">none chosen</span></span></label>
      <label class="pick"><span>2. Its licence</span><span class="inline"><button id="pick-work" class="btn">Choose work.bin</button><span id="work-name" class="dim">none chosen</span></span></label>
      <input id="f-pkg" type="file" accept=".pkg,application/octet-stream" hidden />
      <input id="f-work" type="file" accept=".bin,application/octet-stream" hidden />
      <div class="actions"><button id="go-pkg" class="btn primary" disabled>Import</button></div>
    </div>
    <div class="card mode" id="mode-folder" hidden>
      <p class="dim">A folder dumped from a console (with <code>sce_pfs</code> and <code>sce_sys</code> inside, and the <code>work.bin</code> under <code>sce_sys/package</code>).</p>
      <div class="actions"><button id="pick-dir" class="btn primary">Choose a folder</button></div>
      <input id="f-dir" type="file" webkitdirectory hidden />
    </div>
    <div class="card mode" id="mode-zip" hidden>
      <p class="dim">A zip of either of the above.</p>
      <div class="actions"><button id="pick-zip" class="btn primary">Choose a .zip</button></div>
      <input id="f-zip" type="file" accept=".zip,application/zip" hidden />
    </div>
    <div class="card mode" id="mode-vpk" hidden>
      <p class="dim">A homebrew app as its <code>.vpk</code>, as distributed. Nothing is encrypted, so no licence is needed.</p>
      <div class="actions"><button id="pick-vpk" class="btn primary">Choose a .vpk</button></div>
      <input id="f-vpk" type="file" accept=".vpk,application/zip,application/octet-stream" hidden />
    </div>
    <div id="drop" class="drop"><p class="dim">Or drop files or a folder anywhere here.</p></div>
    <div id="result"></div>`;
  for (const tab of view.querySelectorAll("#tabs .tab")) {
    tab.addEventListener("click", () => {
      for (const t of view.querySelectorAll("#tabs .tab")) t.classList.toggle("on", t === tab);
      for (const m of view.querySelectorAll(".mode")) m.hidden = m.id !== `mode-${tab.dataset.mode}`;
    });
  }
  let pkg = null;
  let work = null;
  const armPkg = () => ($("go-pkg").disabled = !(pkg && work));
  $("pick-pkg").addEventListener("click", () => $("f-pkg").click());
  $("pick-work").addEventListener("click", () => $("f-work").click());
  $("f-pkg").addEventListener("change", (e) => {
    pkg = e.target.files[0] || null;
    $("pkg-name").textContent = pkg ? `${pkg.name} (${store.fmtBytes(pkg.size)})` : "none chosen";
    armPkg();
  });
  $("f-work").addEventListener("change", (e) => {
    work = e.target.files[0] || null;
    $("work-name").textContent = work ? work.name : "none chosen";
    armPkg();
  });
  const start = (entries) => startImport(entries, addonFor);
  $("go-pkg").addEventListener("click", () => start([{ path: pkg.name, file: pkg }, { path: "work.bin", file: work }]));
  $("pick-dir").addEventListener("click", () => $("f-dir").click());
  $("f-dir").addEventListener("change", (e) => e.target.files.length && start(imp.entriesFromFiles(e.target.files)));
  $("pick-vpk").addEventListener("click", () => $("f-vpk").click());
  $("f-vpk").addEventListener("change", (e) => e.target.files.length && start(imp.entriesFromFiles(e.target.files)));
  $("pick-zip").addEventListener("click", () => $("f-zip").click());
  $("f-zip").addEventListener("change", (e) => e.target.files.length && start(imp.entriesFromFiles(e.target.files)));
  const drop = $("drop");
  drop.addEventListener("dragover", (e) => {
    e.preventDefault();
    drop.classList.add("over");
  });
  drop.addEventListener("dragleave", () => drop.classList.remove("over"));
  drop.addEventListener("drop", async (e) => {
    e.preventDefault();
    drop.classList.remove("over");
    const entries = await imp.entriesFromDrop(e.dataTransfer);
    if (entries.length) start(entries);
  });
}

// The ingest's own stage names (copy, decrypt, unwrap) describe the step to whoever is
// reading the code. What a person watching an import needs to know is that it is
// working, so all of them read as one word here.
const stageWord = (s) => (s === "preparing" ? "preparing storage" : "loading");

/// A remaining time a person can read at a glance, and one that does not twitch: at
/// this range a second of precision is noise, so it is coarse on purpose.
function fmtLeft(secs) {
  const s = Math.max(0, Math.round(secs));
  if (s < 55) return `${Math.max(5, Math.round(s / 5) * 5)}s`;
  const m = Math.round(s / 60);
  return m < 60 ? `${m} min` : `${Math.floor(m / 60)}h ${m % 60}m`;
}

// ONE STEP: picking the files IS the import. There is no "we read it, now confirm"
// screen - identifying a package means reading it, which on a phone takes long enough
// to look like a hang, and the confirmation bought a second read of the same bytes.
// The card starts as a progress bar and fills in the title, icon and size as the
// worker reports them, part way through the import it is already running.
async function startImport(entries, addonFor = null) {
  const result = $("result");
  // The pickers go away while this runs: a second pick would start a second import
  // into the same directory.
  const hidden = [...view.querySelectorAll("#tabs, .mode, #drop")].filter((el) => !el.hidden);
  for (const el of hidden) el.hidden = true;
  const picked = entries.reduce((a, e) => a + e.file.size, 0);
  result.innerHTML = `<div class="card confirm">
    <span class="icon big noicon" id="imp-icon"></span>
    <div>
      <h2 id="imp-title">Reading ${entries.length} file${entries.length === 1 ? "" : "s"}...</h2>
      <p class="meta" id="imp-meta">${store.fmtBytes(picked)} picked. Keep this tab open; a large title takes a few minutes.</p>
      <div id="progress"><div class="bar"><div id="bar-fill"></div></div><p id="prog-text" class="dim">starting</p></div>
    </div></div>`;
  const fill = $("bar-fill");
  const text = $("prog-text");
  let probe = null;
  // The library record of the title being replaced, as a PROMISE: `onProbe` is called
  // from a message handler that nobody awaits, so the value it resolves to has to be
  // waited for where it is used (`lastPlayedAt`), not assumed to have arrived.
  let existingP = null;
  let iconUrl = null;
  try {
    const done = await imp.run(
      entries,
      async (p) => {
        probe = p;
        existingP = p.titleId && !addonFor ? store.readTitle(p.titleId) : null;
        const existing = existingP ? await existingP : null;
        if (p.icon0) {
          iconUrl = URL.createObjectURL(new Blob([p.icon0], { type: "image/png" }));
          const icon = $("imp-icon");
          if (icon) {
            icon.classList.remove("noicon");
            icon.innerHTML = `<img src="${iconUrl}" alt="" />`;
          }
        }
        const title = $("imp-title");
        const meta = $("imp-meta");
        if (title) title.textContent = p.title || p.addonDir || p.titleId || "Unknown title";
        if (meta) {
          meta.textContent =
            `${p.isAddon ? `add-on ${p.addonDir || ""} for ` : ""}${p.titleId || "no title id"}${p.appVersion ? " - v" + p.appVersion : ""} - ` +
            `${p.kind === "vpk" ? "homebrew" : p.kind + (p.zipped ? " in a zip" : "")} - ${p.files} files - ${store.fmtBytes(p.bytes)}` +
            (existing ? ` - replacing what is in the library (saved data is kept)` : "");
        }
      },
      (p) => {
        if (p.stage === "reading") {
          fill.style.width = "0%";
          text.textContent = `identifying, read ${store.fmtBytes(p.done)}${p.file ? ` - ${p.file}` : ""}`;
          return;
        }
        if (p.unit === "files") {
          fill.style.width = `${Math.min(100, (100 * p.done) / p.total)}%`;
          text.textContent = `preparing storage, ${p.done} of ${p.total} files`;
          return;
        }
        if (!p.total) {
          text.textContent = p.stage === "preparing" ? "preparing storage" : stageWord(p.stage);
          return;
        }
        const pct = Math.min(100, (100 * p.done) / p.total);
        fill.style.width = `${pct}%`;
        const left = p.rate > 0 ? `, about ${fmtLeft((p.total - p.done) / p.rate)} left` : "";
        text.textContent = `${stageWord(p.stage)} ${store.fmtBytes(p.done)} / ${store.fmtBytes(p.total)}${p.rate ? ` at ${(p.rate / 1e6).toFixed(0)} MB/s` : ""}${left} - ${p.file}`;
      },
      { addonFor }
    );
    const id = done.titleId;
    if (addonFor) {
      fill.style.width = "100%";
      text.textContent = "done";
      go(`#/title/${addonFor}`);
      return;
    }
    const existing = existingP ? await existingP : null;
    const meta = {
      titleId: id,
      title: (probe && probe.title) || id,
      contentId: done.contentId || (probe && probe.contentId) || "",
      appVersion: (probe && probe.appVersion) || "",
      sourceKind: probe ? probe.kind : "",
      bytes: probe ? probe.bytes : picked,
      files: done.count,
      hasIcon: !!(probe && probe.icon0),
      hasPic: !!(probe && probe.pic0),
      importedAt: Date.now(),
      lastPlayedAt: existing ? existing.lastPlayedAt || 0 : 0,
    };
    await store.removeTitleRecord(id);
    await store.writeTitle(meta, { "icon0.png": probe && probe.icon0, "pic0.png": probe && probe.pic0 });
    fill.style.width = "100%";
    text.textContent = "done";
    go(`#/title/${id}`);
  } catch (err) {
    text.textContent = "";
    for (const el of hidden) el.hidden = false;
    const unknown = /unknown container|not a title|no param\.sfo|work\.bin/i.test(String(err.message || err));
    result.innerHTML = "";
    result.insertAdjacentHTML(
      "beforeend",
      `<div class="card error"><h2>${unknown ? "Not a title this emulator recognises" : "Import failed"}</h2><pre>${esc(err.message || err)}</pre>
       ${unknown ? `<p class="dim">It looks for a .pkg (with its work.bin picked alongside), a folder with sce_pfs/files.db, or a homebrew .vpk.</p>` : ""}
       <p class="dim">Pick again above to retry.</p></div>`
    );
  }
}

// ------------------------------- about -------------------------------

async function renderAbout() {
  view.innerHTML = `
    <h1>About</h1>
    <div class="card">
      <p>vitaslop is a clean-room PlayStation Vita emulator that runs entirely in this browser: a title's ARM code is translated to WebAssembly and run on the browser's own engine, its GPU stream is drawn with WebGPU, and everything you import stays in this browser's private storage. No server, no console firmware, no downloads from anywhere.</p>
      <p><a href="https://github.com/cretz/vitaslop">Source and documentation on GitHub</a>. Titles are never provided; import your own from a console you own.</p>
    </div>
    <section class="card"><h2>This browser</h2>${featureList()}</section>`;
}

// ------------------------------- boot -------------------------------

(async () => {
  if (await ensureIsolation()) return;
  features = await checkFeatures();
  playable = canPlay(features);
  const resume = sessionStorage.getItem("vitaslop.resume");
  if (resume) {
    sessionStorage.removeItem("vitaslop.resume");
    location.hash = resume;
  }
  route();
  // The settings logic lives in the emulator bundle, and a title page needs it (see
  // `renderTitle`). Loading it now, behind whatever page is showing, means it is usually ready
  // by the time a title is opened. A failure here is not reported: the page that needs the
  // bundle awaits it itself and says what went wrong.
  store.wasm().catch(() => {});
})();
