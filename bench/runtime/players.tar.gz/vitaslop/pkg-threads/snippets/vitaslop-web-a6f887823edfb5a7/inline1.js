
export function copy_range(src, off, dst) {
  dst.set(src.subarray(off, off + dst.length));
}
export function write_range(dst, off, src) {
  dst.set(src, off);
}
export function any_ge(u8, from, to, stamp) {
  for (let i = from; i < to; i++) if (u8[i] >= stamp) return true;
  return false;
}
export function copy_ranges(src, table, dst) {
  let at = 0;
  for (let i = 0; i < table.length; i += 2) {
    const off = table[i], len = table[i + 1];
    const end = Math.min(off + len, src.length);
    if (end > off) dst.set(src.subarray(off, end), at);
    at += len;
  }
}
