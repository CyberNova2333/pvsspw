
export function save_some(globals, idxs, out) {
  for (let k = 0; k < idxs.length; k++) { const i = idxs[k]; out[i] = globals[i].value; }
}
export function set_one(g, v) { g.value = v; }
