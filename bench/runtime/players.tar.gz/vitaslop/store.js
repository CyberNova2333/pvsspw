// Where the front end keeps what it knows: settings (global and per title) and the
// library index. Titles' bytes live under `games/<id>/` (opfs.js) and saves under
// `gamedata/` (gamedata.js); this file owns `library/<id>/` and localStorage.
//
// Settings are localStorage because they are small, synchronous to read, and must be
// there before the first frame of the page. The library is OPFS because it is
// per-title files (a JSON record plus two images), and OPFS is what survives with the
// titles - a cleared localStorage must not orphan a gigabyte of imported games.
//
// The RULES for settings (defaults, merge, which knob a checkbox means) are in Rust
// (`vitaslop-frontend`), reached through the wasm exports; this file only stores.

import init, {
  settings_defaults,
  settings_effective,
  settings_run_knobs,
  settings_parse_knobs,
  input_vocabulary,
} from "./pkg/vitaslop_web.js";

let ready = null;
/// The wasm module, initialised once for the page. Cheap after the first call.
export function wasm() {
  if (!ready) {
    ready = init().then(
      (m) => {
        bundleLoaded("pkg");
        return m;
      },
      (err) => recoverFromMixedBuild(err, "pkg")
    );
  }
  return ready;
}

// >>> A PAGE LOADED DURING A DEPLOY CAN HOLD TWO BUILDS. The host lets a browser keep each file
// for minutes, and the glue JS and the wasm are cached separately - so a visit soon after a
// deploy can pair the new glue with the old wasm (or the reverse), and instantiating fails with
// a LinkError ("function import requires a callable"). Seen on a phone right after a merge.
// That error is fixed by fetching both bundles again past the cache and reloading, so the page
// does exactly that - once per tab session PER BUNDLE, so a genuinely broken deploy shows its
// error instead of reloading forever. The page's own `pkg` initialises here; `pkg-threads` only
// in the run and transpile workers, whose LinkError reaches the player (player.js `start`),
// which recovers through the same function.
// The guard is per bundle and cleared only when THAT bundle instantiates: one shared marker
// would be cleared by `pkg` loading fine after the reload, and a still-mixed `pkg-threads`
// would then reload on every play.
const MIXED_BUILD_KEY = (bundle) => `vitaslop.mixed-build-reload.${bundle}`;
const BUNDLE_FILES = ["pkg/vitaslop_web.js", "pkg/vitaslop_web_bg.wasm", "pkg-threads/vitaslop_web.js", "pkg-threads/vitaslop_web_bg.wasm"];

/// `bundle` ("pkg" or "pkg-threads") instantiated: a later mixed load of it may recover again.
export function bundleLoaded(bundle) {
  try {
    sessionStorage.removeItem(MIXED_BUILD_KEY(bundle));
  } catch {}
}

/// Refetch the bundles and reload once if `err` is a LinkError from `bundle`; otherwise (or on a
/// second try in this tab session) rethrow it. A worker's error arrives as a plain `Error`
/// carrying `linkError: true` (a worker message cannot carry the error's class).
export async function recoverFromMixedBuild(err, bundle) {
  const linkError = err instanceof WebAssembly.LinkError || !!(err && err.linkError) || /LinkError/.test(String(err));
  let tried = true;
  try {
    tried = sessionStorage.getItem(MIXED_BUILD_KEY(bundle)) === "1";
    if (linkError && !tried) sessionStorage.setItem(MIXED_BUILD_KEY(bundle), "1");
  } catch {}
  if (!linkError || tried) throw err;
  // `cache: "reload"` fetches from the server AND stores the answer, so the reload finds fresh
  // copies. The bodies are read to the end first: `fetch` resolves on the headers, and a reload
  // with a download still running cancels it before it reaches the cache.
  await Promise.all(
    BUNDLE_FILES.map((f) =>
      fetch(new URL(f, import.meta.url), { cache: "reload" })
        .then((r) => r.arrayBuffer())
        .catch(() => {})
    )
  );
  location.reload();
  return new Promise(() => {});
}

const GLOBAL_KEY = "vitaslop.settings";
const TITLE_KEY = (id) => `vitaslop.title.${id}`;

function readJson(key) {
  try {
    const s = localStorage.getItem(key);
    return s ? JSON.parse(s) : null;
  } catch {
    return null;
  }
}
function writeJson(key, v) {
  try {
    if (v === null) localStorage.removeItem(key);
    else localStorage.setItem(key, JSON.stringify(v));
  } catch {}
}

/// The stored global record (a partial object; missing keys are defaults).
export const globalSettings = () => readJson(GLOBAL_KEY) || {};
export const saveGlobalSettings = (obj) => writeJson(GLOBAL_KEY, obj);
/// The stored per-title patch (only what differs for this title), or {}.
export const titleSettings = (id) => readJson(TITLE_KEY(id)) || {};
export const saveTitleSettings = (id, patch) =>
  writeJson(TITLE_KEY(id), patch && Object.keys(patch).length ? patch : null);

/// The full default record.
export async function defaults() {
  await wasm();
  return JSON.parse(settings_defaults());
}

/// The settings a run of `id` uses: defaults + global + the title's patch.
export async function effective(id = null) {
  await wasm();
  const g = JSON.stringify(globalSettings());
  const p = id ? JSON.stringify(titleSettings(id)) : null;
  return JSON.parse(settings_effective(g, p));
}

/// The VITASLOP_* map for an effective record.
export async function runKnobs(eff) {
  await wasm();
  return settings_run_knobs(JSON.stringify(eff));
}

export async function parseKnobs(text) {
  await wasm();
  return settings_parse_knobs(text);
}

export async function vocabulary() {
  await wasm();
  return input_vocabulary();
}

// ------------------------------- the library -------------------------------

async function libraryRoot(create = true) {
  const root = await navigator.storage.getDirectory();
  return root.getDirectoryHandle("library", { create });
}

/// Every imported title's record, newest import first. Reads one small JSON per
/// title and no image bytes, so a thousand titles is a thousand short reads.
export async function listTitles() {
  let lib;
  try {
    lib = await libraryRoot(false);
  } catch {
    return [];
  }
  const out = [];
  for await (const [name, handle] of lib.entries()) {
    if (handle.kind !== "directory") continue;
    try {
      const fh = await handle.getFileHandle("meta.json");
      const meta = JSON.parse(await (await fh.getFile()).text());
      if (meta && meta.titleId === name) out.push(meta);
    } catch {
      // A directory without a record is a half-finished import; it is not a title.
    }
  }
  out.sort((a, b) => (b.importedAt || 0) - (a.importedAt || 0));
  return out;
}

export async function readTitle(id) {
  try {
    const lib = await libraryRoot(false);
    const dir = await lib.getDirectoryHandle(id);
    const fh = await dir.getFileHandle("meta.json");
    return JSON.parse(await (await fh.getFile()).text());
  } catch {
    return null;
  }
}

export async function writeTitle(meta, images = {}) {
  const lib = await libraryRoot(true);
  const dir = await lib.getDirectoryHandle(meta.titleId, { create: true });
  for (const [name, bytes] of Object.entries(images)) {
    if (!bytes) continue;
    const fh = await dir.getFileHandle(name, { create: true });
    const w = await fh.createWritable();
    await w.write(bytes);
    await w.close();
  }
  const fh = await dir.getFileHandle("meta.json", { create: true });
  const w = await fh.createWritable();
  await w.write(JSON.stringify(meta));
  await w.close();
}

export async function touchTitle(id, patch) {
  const meta = await readTitle(id);
  if (!meta) return;
  await writeTitle({ ...meta, ...patch });
}

/// An object URL for a title's image, or null. Cached for the page's life so the
/// grid does not re-read a thousand PNGs on every render.
const imageUrls = new Map();
export async function titleImage(id, name = "icon0.png") {
  const key = `${id}/${name}`;
  if (imageUrls.has(key)) return imageUrls.get(key);
  let url = null;
  try {
    const lib = await libraryRoot(false);
    const dir = await lib.getDirectoryHandle(id);
    const fh = await dir.getFileHandle(name);
    url = URL.createObjectURL(await fh.getFile());
  } catch {}
  imageUrls.set(key, url);
  return url;
}

/// Remove a title's record and images (not its bytes and not its saves - the
/// caller does those, deliberately separately).
export async function removeTitleRecord(id) {
  try {
    const lib = await libraryRoot(false);
    await lib.removeEntry(id, { recursive: true });
  } catch {}
  for (const k of [...imageUrls.keys()]) {
    if (k.startsWith(id + "/")) {
      const u = imageUrls.get(k);
      if (u) URL.revokeObjectURL(u);
      imageUrls.delete(k);
    }
  }
}

/// Bytes used by one imported title's files, summed from OPFS.
///
/// >>> REMEMBERED IN THE TITLE'S RECORD, because summing it is not cheap: one `getFile()` per
/// stored file, and a title is up to ~1,300 files at several ms each on a phone - the title page
/// used to wait on this before drawing anything, and "hung a second" every time it opened. The
/// stored bytes never change after an import (a re-import writes a fresh record without it), so
/// it is summed once, in parallel, and read from `meta.storedBytes` from then on.
export async function titleBytes(id) {
  const meta = await readTitle(id);
  if (meta && typeof meta.storedBytes === "number") return meta.storedBytes;
  let n = 0;
  try {
    const root = await navigator.storage.getDirectory();
    const games = await root.getDirectoryHandle("games");
    const dir = await games.getDirectoryHandle(id);
    const files = [];
    for await (const [, h] of dir.entries()) if (h.kind === "file") files.push(h);
    const sizes = await Promise.all(files.map(async (h) => (await h.getFile()).size));
    n = sizes.reduce((a, b) => a + b, 0);
  } catch {
    return 0;
  }
  if (meta && n > 0) await touchTitle(id, { storedBytes: n });
  return n;
}

/// Human sizes. 1e6-based, because that is what disks and quotas are quoted in.
export function fmtBytes(n) {
  if (!n) return "0 MB";
  if (n < 1e6) return `${(n / 1e3).toFixed(0)} KB`;
  if (n < 1e9) return `${(n / 1e6).toFixed(0)} MB`;
  return `${(n / 1e9).toFixed(2)} GB`;
}
